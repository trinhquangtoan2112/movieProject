export const DOMAIN ="https://movieapi.cyberlearn.vn";
export const TOKEN = 'accessToken';
export const GROUPID = 'GP01';


export const USER_LOGIN = 'USER_LOGIN';