

export const UserTemplates =(props)=>{

    const {props1}  =props;
    const {Header,Footer}=props1;
    const {Homepage,...otherProp} =props1;
    
     return <div>
      <Homepage></Homepage>
        </div>
 
}