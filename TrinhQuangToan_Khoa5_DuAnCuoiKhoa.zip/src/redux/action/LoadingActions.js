import { DISPLAY_LOADING, HIDE_LOADING } from "../types/LoadingType"

export const displayLoadingAction = {
    type:DISPLAY_LOADING
}



export const hideLoadingAction = {
    type:HIDE_LOADING
}