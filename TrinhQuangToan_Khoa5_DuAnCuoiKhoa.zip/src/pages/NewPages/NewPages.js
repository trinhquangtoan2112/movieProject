import React from 'react'

export default function NewPages() {
  return (
    <div>NewPages</div>
  )
}
